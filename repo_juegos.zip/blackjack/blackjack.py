"""
============================================================
  BLACKJACK 21 - Tu contra la maquina  (VERSION GRAFICA)
  Ventana grande estilo casino, controles con botones.
  Requiere: tkinter (incluido con Python) y pygame (musica):
      pip install pygame
  Deja musica.wav y los efectos .wav junto a este script.
  Atajos de teclado: 1 = Pedir | 2 = Plantarse | 3 = Doblar | M = Musica
============================================================
"""

import os
import random
import tkinter as tk
from tkinter import messagebox

try:
    import pygame
    PYGAME_OK = True
except ImportError:
    PYGAME_OK = False

# -------------------- CONFIGURACION --------------------
BANCA_INICIAL  = 1000
APUESTA_MINIMA = 10
PAGO_BJ        = 1.5
TOPE_CRUPIER   = 17
UMBRAL_BARAJA  = 15
PRESTAMO       = 500
RETARDO_CRUPIER = 750   # milisegundos entre cartas del crupier

MUSICA_ARCHIVO = "musica.wav"
VOLUMEN_MUSICA = 0.35
VOLUMEN_EFECTOS = 0.8
EFECTOS = ["carta", "ganar", "perder", "empate", "blackjack"]

# Palo: (simbolo, color_de_dibujo)
PALOS = [("♠", "#222222"), ("♥", "#c0392b"),
         ("♦", "#c0392b"), ("♣", "#222222")]
RANGOS = ["A", "2", "3", "4", "5", "6", "7",
          "8", "9", "10", "J", "Q", "K"]

# Colores de la interfaz
FONDO_MESA   = "#5c0e2f"
FONDO_PANEL  = "#08351f"
DORADO       = "#f1c40f"
TEXTO_CLARO  = "#ecf0f1"
VERDE_BTN    = "#ae277a"
ROJO_BTN     = "#c0392b"
NARANJA_BTN  = "#e67e22"
AZUL_BTN     = "#2471a3"
ANCHO_CARTA  = 96
ALTO_CARTA   = 136
SEPARACION   = 78


# -------------------- NUCLEO (misma logica que antes) --------------------
def crear_baraja():
    """Baraja nueva de 52 cartas: (rango, simbolo, color)."""
    baraja = [(r, s, c) for r in RANGOS for (s, c) in PALOS]
    random.shuffle(baraja)
    return baraja


def valor_mano(mano):
    """Valor de la mano; el As vale 11 u 1, lo que convenga."""
    total, ases = 0, 0
    for rango, _, _ in mano:
        if rango in ("J", "Q", "K"):
            total += 10
        elif rango == "A":
            total += 11
            ases += 1
        else:
            total += int(rango)
    while total > 21 and ases:
        total -= 10
        ases -= 1
    return total


def mano_a_texto(mano):
    return "  |  ".join(f"{r} de {s}" for r, s, _ in mano)


# -------------------- VENTANA PRINCIPAL --------------------
class BlackjackApp:
    def __init__(self, root):
        self.root = root
        self.root.title("♠ BLACKJACK 21 - Tu contra la maquina ♥")
        self.root.geometry("1200x780")
        self.root.configure(bg=FONDO_MESA)
        self.root.resizable(False, False)

        self.reset_juego()
        self.iniciar_musica()
        self.construir_interfaz()
        self.nueva_ronda()

    # ---------- estado general ----------
    def reset_juego(self):
        self.baraja = crear_baraja()
        self.banca = BANCA_INICIAL
        self.stats = {"rondas": 0, "victorias": 0, "derrotas": 0,
                      "empates": 0, "racha": 0, "racha_max": 0,
                      "banca_max": BANCA_INICIAL, "prestamos": 0,
                      "deuda": 0}
        self.apuesta = 0
        self.mano_jugador = []
        self.mano_crupier = []
        self.estado = "apostando"   # apostando | jugador | crupier | fin

    # ---------- construccion de la interfaz ----------
    def construir_interfaz(self):
        # Titulo
        tk.Label(self.root, text="♠ ♥ BLACKJACK 21 ♦ ♣",
                 font=("Helvetica", 26, "bold"),
                 bg=FONDO_MESA, fg=DORADO).place(x=600, y=18, anchor="n")

        # ---- Zona del crupier ----
        tk.Label(self.root, text="CRUPIER", font=("Helvetica", 15, "bold"),
                 bg=FONDO_MESA, fg=TEXTO_CLARO).place(x=560, y=70, anchor="n")
        self.canvas_crupier = tk.Canvas(self.root, width=560, height=150,
                                        bg=FONDO_MESA, highlightthickness=0)
        self.canvas_crupier.place(x=560, y=100, anchor="n")

        # ---- Mensaje central ----
        self.var_mensaje = tk.StringVar()
        tk.Label(self.root, textvariable=self.var_mensaje,
                 font=("Helvetica", 16, "bold"),
                 bg=FONDO_MESA, fg=DORADO).place(x=600, y=268, anchor="center")

        # ---- Zona del jugador ----
        tk.Label(self.root, text="TU MANO", font=("Helvetica", 15, "bold"),
                 bg=FONDO_MESA, fg=TEXTO_CLARO).place(x=560, y=305, anchor="n")
        self.canvas_jugador = tk.Canvas(self.root, width=560, height=150,
                                        bg=FONDO_MESA, highlightthickness=0)
        self.canvas_jugador.place(x=560, y=335, anchor="n")

        # ---- Panel derecho: datos del jugador ----
        panel = tk.Frame(self.root, bg=FONDO_PANEL, bd=3, relief="ridge")
        panel.place(x=930, y=70, width=250, height=415)
        tk.Label(panel, text="TU CUENTA", font=("Helvetica", 14, "bold"),
                 bg=FONDO_PANEL, fg=DORADO).pack(pady=(10, 6))

        self.var_banca = tk.StringVar()
        self.var_apuesta = tk.StringVar()
        self.var_racha = tk.StringVar()
        self.var_record = tk.StringVar()
        for texto, var in (("Banca:", self.var_banca),
                           ("Apuesta:", self.var_apuesta),
                           ("Racha de victorias:", self.var_racha),
                           ("Banca maxima:", self.var_record)):
            tk.Label(panel, text=texto, font=("Helvetica", 12),
                     bg=FONDO_PANEL, fg=TEXTO_CLARO).pack(anchor="w", padx=14)
            tk.Label(panel, textvariable=var, font=("Helvetica", 14, "bold"),
                     bg=FONDO_PANEL, fg=DORADO).pack(anchor="w", padx=26)

        # Bitacora de resultados
        tk.Label(panel, text="Bitacora:", font=("Helvetica", 12),
                 bg=FONDO_PANEL, fg=TEXTO_CLARO).pack(anchor="w", padx=14, pady=(12, 2))
        self.bitacora = tk.Listbox(panel, height=8, font=("Helvetica", 10),
                                   bg="#052013", fg=TEXTO_CLARO,
                                   highlightthickness=0, bd=0)
        self.bitacora.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # ---- Barra inferior: apuesta y acciones ----
        barra = tk.Frame(self.root, bg=FONDO_MESA)
        barra.place(x=600, y=560, anchor="n")

        tk.Label(barra, text="Tu apuesta:", font=("Helvetica", 14, "bold"),
                 bg=FONDO_MESA, fg=TEXTO_CLARO).grid(row=0, column=0, padx=8)
        self.var_apuesta_input = tk.IntVar(value=APUESTA_MINIMA)
        self.spin_apuesta = tk.Spinbox(barra, from_=APUESTA_MINIMA,
                                       to=self.banca, increment=10,
                                       textvariable=self.var_apuesta_input,
                                       width=8, font=("Helvetica", 15, "bold"),
                                       justify="center")
        self.spin_apuesta.grid(row=0, column=1, padx=8)

        self.btn_repartir = self._boton(barra, "REPARTIR", AZUL_BTN,
                                        self.apostar, 0, 2)
        self.btn_musica = self._boton(barra, "♪ MUSICA: ON" if self.musica_sonando
                                      else "♪ MUSICA: OFF", "#8e44ad",
                                      self.alternar_musica, 0, 3)
        self.btn_pedir = self._boton(barra, "1 · PEDIR", VERDE_BTN,
                                     self.pedir, 1, 0)
        self.btn_plantarse = self._boton(barra, "2 · PLANTARSE", ROJO_BTN,
                                         self.plantarse, 1, 1)
        self.btn_doblar = self._boton(barra, "3 · DOBLAR", NARANJA_BTN,
                                      self.doblar, 1, 2)
        self.btn_salir = self._boton(barra, "SALIR", "#7f8c8d",
                                     self.salir, 1, 3)

        # Atajos de teclado
        self.root.bind("<KeyPress-1>", lambda e: self.pedir())
        self.root.bind("<KeyPress-2>", lambda e: self.plantarse())
        self.root.bind("<KeyPress-3>", lambda e: self.doblar())
        self.root.bind("<KeyPress-m>", lambda e: self.alternar_musica())

    def _boton(self, padre, texto, color, comando, fila, columna):
        btn = tk.Button(padre, text=texto, font=("Helvetica", 13, "bold"),
                        bg=color, fg="white", activebackground=color,
                        width=13, cursor="hand2", bd=0, relief="flat",
                        command=comando)
        btn.grid(row=fila, column=columna, padx=8, pady=8)
        return btn

    # ---------- musica ----------
    def iniciar_musica(self):
        self.musica_cargada = False
        self.musica_sonando = False
        self.sonidos = {}
        if not PYGAME_OK:
            print("pygame no esta instalado. Ejecuta: pip install pygame")
            return
        try:
            pygame.mixer.init(44100, -16, 2, 512)
            carpeta = os.path.dirname(os.path.abspath(__file__))
            for nombre in EFECTOS:
                try:
                    snd = pygame.mixer.Sound(os.path.join(carpeta, nombre + ".wav"))
                    snd.set_volume(VOLUMEN_EFECTOS)
                    self.sonidos[nombre] = snd
                except Exception as e:
                    print("Sin efecto", nombre, ":", e)
            ruta = os.path.join(carpeta, MUSICA_ARCHIVO)
            pygame.mixer.music.load(ruta)
            pygame.mixer.music.set_volume(VOLUMEN_MUSICA)
            pygame.mixer.music.play(-1)   # -1 = loop infinito
            self.musica_cargada = True
            self.musica_sonando = True
        except Exception as e:
            print("No se pudo cargar la musica:", e)

    def sfx(self, nombre):
        snd = self.sonidos.get(nombre)
        if snd:
            snd.play()

    def alternar_musica(self):
        if not self.musica_cargada:
            return
        if self.musica_sonando:
            pygame.mixer.music.pause()
            self.btn_musica.config(text="♪ MUSICA: OFF")
        else:
            pygame.mixer.music.unpause()
            self.btn_musica.config(text="♪ MUSICA: ON")
        self.musica_sonando = not self.musica_sonando

    # ---------- dibujo de cartas ----------
    def _redondeado(self, canvas, x, y, w, h, radio, **kwargs):
        puntos = [x + radio, y, x + w - radio, y, x + w, y,
                  x + w, y + radio, x + w, y + h - radio, x + w, y + h,
                  x + w - radio, y + h, x + radio, y + h, x, y + h,
                  x, y + h - radio, x, y + radio, x, y]
        return canvas.create_polygon(puntos, smooth=True, **kwargs)

    def dibujar_mano(self, canvas, mano, ocultar_segunda=False):
        canvas.delete("all")
        for i, carta in enumerate(mano):
            x = 10 + i * SEPARACION
            if ocultar_segunda and i == 1:
                # Dorso de la carta
                self._redondeado(canvas, x, 5, ANCHO_CARTA, ALTO_CARTA, 12,
                                 fill="#1f3a93", outline="#0c1e4d", width=3)
                canvas.create_text(x + ANCHO_CARTA // 2, ALTO_CARTA // 2 + 5,
                                   text="★", font=("Helvetica", 40),
                                   fill=DORADO)
            else:
                rango, simbolo, color = carta
                self._redondeado(canvas, x, 5, ANCHO_CARTA, ALTO_CARTA, 12,
                                 fill="white", outline="#999999", width=2)
                canvas.create_text(x + 13, 17, text=rango,
                                   font=("Helvetica", 18, "bold"),
                                   fill=color, anchor="n")
                canvas.create_text(x + ANCHO_CARTA // 2, ALTO_CARTA // 2 + 12,
                                   text=simbolo, font=("Helvetica", 42),
                                   fill=color)
                canvas.create_text(x + ANCHO_CARTA - 13, ALTO_CARTA - 12,
                                   text=rango, font=("Helvetica", 18, "bold"),
                                   fill=color, anchor="s")

    # ---------- flujo del juego ----------
    def nueva_ronda(self):
        self.estado = "apostando"
        self.mano_jugador, self.mano_crupier = [], []
        self.dibujar_mano(self.canvas_jugador, [])
        self.dibujar_mano(self.canvas_crupier, [])
        self.var_mensaje.set("Elige tu apuesta y pulsa REPARTIR")
        self.spin_apuesta.config(state=tk.NORMAL,
                                 to=max(self.banca, APUESTA_MINIMA))
        self.btn_repartir.config(state=tk.NORMAL)
        for btn in (self.btn_pedir, self.btn_plantarse, self.btn_doblar):
            btn.config(state=tk.DISABLED)
        self.actualizar_panel()

    def apostar(self):
        if self.estado != "apostando":
            return
        try:
            apuesta = int(self.var_apuesta_input.get())
        except (tk.TclError, ValueError):
            messagebox.showwarning("Apuesta invalida",
                                   "Escribe un numero entero.")
            return
        if apuesta < APUESTA_MINIMA:
            messagebox.showwarning("Apuesta invalida",
                                   f"La apuesta minima es ${APUESTA_MINIMA}.")
            return
        if apuesta > self.banca:
            messagebox.showwarning("Apuesta invalida",
                                   f"No tienes tanto. Tu banca: ${self.banca}.")
            return

        self.apuesta = apuesta
        if len(self.baraja) < UMBRAL_BARAJA:
            self.baraja = crear_baraja()
            self.log("Se mezcla una baraja nueva.")
        self.mano_jugador = [self.baraja.pop(), self.baraja.pop()]
        self.mano_crupier = [self.baraja.pop(), self.baraja.pop()]
        self.stats["rondas"] += 1
        self.stats["banca_max"] = max(self.stats["banca_max"], self.banca)

        self.spin_apuesta.config(state=tk.DISABLED)
        self.btn_repartir.config(state=tk.DISABLED)
        self.btn_pedir.config(state=tk.NORMAL)
        self.btn_plantarse.config(state=tk.NORMAL)
        self.dibujar_mano(self.canvas_jugador, self.mano_jugador)
        self.dibujar_mano(self.canvas_crupier, self.mano_crupier,
                          ocultar_segunda=True)
        for i in range(4):
            self.root.after(i * 140, lambda: self.sfx("carta"))

        bj_j = valor_mano(self.mano_jugador) == 21
        bj_c = valor_mano(self.mano_crupier) == 21
        if bj_j or bj_c:
            self.dibujar_mano(self.canvas_crupier, self.mano_crupier)
            if bj_j and bj_c:
                self.resolver("push", "Empate de blackjacks. Recuperas tu apuesta.")
            elif bj_j:
                ganancia = int(self.apuesta * PAGO_BJ)
                self.banca += ganancia
                self.resolver("win", f"BLACKJACK NATURAL! Ganaste ${ganancia}.",
                              sonido="blackjack")
            else:
                self.banca -= self.apuesta
                self.resolver("lose", "El crupier tiene blackjack. Pierdes.")
        else:
            self.estado = "jugador"
            self.var_mensaje.set(f"Tienes {valor_mano(self.mano_jugador)}. "
                                 "¿Pedir (1), plantarse (2) o doblar (3)?")
            self.actualizar_panel()

    def pedir(self):
        if self.estado != "jugador":
            return
        self.mano_jugador.append(self.baraja.pop())
        self.sfx("carta")
        self.dibujar_mano(self.canvas_jugador, self.mano_jugador)
        total = valor_mano(self.mano_jugador)
        if total > 21:
            self.banca -= self.apuesta
            self.resolver("lose", f"Te pasaste con {total}. "
                                  f"Pierdes ${self.apuesta}.")
        else:
            self.var_mensaje.set(f"Tienes {total}. ¿Pedir (1) o plantarse (2)?")

    def plantarse(self):
        if self.estado != "jugador":
            return
        self.estado = "crupier"
        self.dibujar_mano(self.canvas_crupier, self.mano_crupier)
        self.btn_pedir.config(state=tk.DISABLED)
        self.btn_plantarse.config(state=tk.DISABLED)
        self.btn_doblar.config(state=tk.DISABLED)
        self.turno_crupier()

    def doblar(self):
        if self.estado != "jugador" or len(self.mano_jugador) != 2:
            return
        if self.banca < self.apuesta * 2:
            messagebox.showwarning("No puedes doblar",
                                   "No tienes banca suficiente para doblar.")
            return
        self.apuesta *= 2
        self.mano_jugador.append(self.baraja.pop())
        self.sfx("carta")
        self.dibujar_mano(self.canvas_jugador, self.mano_jugador)
        total = valor_mano(self.mano_jugador)
        self.actualizar_panel()
        if total > 21:
            self.banca -= self.apuesta
            self.resolver("lose", f"Doblaste y te pasaste con {total}. "
                                  f"Pierdes ${self.apuesta}.")
        else:
            self.log(f"Doblaste: apuesta sube a ${self.apuesta}.")
            self.plantarse()

    def turno_crupier(self):
        if self.estado != "crupier":
            return
        if valor_mano(self.mano_crupier) < TOPE_CRUPIER:
            self.mano_crupier.append(self.baraja.pop())
            self.sfx("carta")
            self.dibujar_mano(self.canvas_crupier, self.mano_crupier)
            self.var_mensaje.set(
                f"El crupier pide... tiene {valor_mano(self.mano_crupier)}")
            self.root.after(RETARDO_CRUPIER, self.turno_crupier)
        else:
            self.comparar()

    def comparar(self):
        v_j = valor_mano(self.mano_jugador)
        v_c = valor_mano(self.mano_crupier)
        if v_c > 21:
            self.banca += self.apuesta
            self.resolver("win", f"El crupier se paso con {v_c}. "
                                 f"Ganaste ${self.apuesta}!")
        elif v_j > v_c:
            self.banca += self.apuesta
            self.resolver("win", f"{v_j} vs {v_c}. Ganaste ${self.apuesta}!")
        elif v_j < v_c:
            self.banca -= self.apuesta
            self.resolver("lose", f"{v_j} vs {v_c}. Pierdes ${self.apuesta}.")
        else:
            self.resolver("push", f"Empate a {v_j}. Recuperas tu apuesta.")

    # ---------- resolucion de ronda ----------
    def resolver(self, resultado, mensaje, sonido=None):
        self.estado = "fin"
        self.sfx(sonido or {"win": "ganar", "lose": "perder",
                            "push": "empate"}[resultado])
        self.var_mensaje.set(mensaje)
        self.log(mensaje)
        if resultado == "win":
            self.stats["victorias"] += 1
            self.stats["racha"] += 1
        elif resultado == "lose":
            self.stats["derrotas"] += 1
            self.stats["racha"] = 0
        else:
            self.stats["empates"] += 1
        self.stats["racha_max"] = max(self.stats["racha_max"],
                                      self.stats["racha"])
        self.stats["banca_max"] = max(self.stats["banca_max"], self.banca)
        self.actualizar_panel()
        self.root.after(1600, self.fin_ronda)

    def fin_ronda(self):
        if self.estado != "fin":
            return
        if self.banca < APUESTA_MINIMA:
            self.prestamista()
        else:
            self.nueva_ronda()

    # ---------- prestamista ----------
    def prestamista(self):
        n = self.stats["prestamos"]
        if n == 0:
            texto = ("Un tipo de traje gastado se acerca a tu mesa:\n\n"
                     "\"Sin plata, campeon? Yo te presto. "
                     "Sin intereses... por ahora.\"")
        elif n == 1:
            texto = ("El prestamista sonrie:\n\n"
                     "\"Otra vez? Cuidadito con mi paciencia.\"")
        else:
            texto = ("El prestamista te mira feo:\n\n"
                     "\"La proxima te cobro con los dientes. Toma.\"")
        if messagebox.askyesno("El prestamista", texto):
            self.stats["prestamos"] += 1
            self.stats["deuda"] += PRESTAMO
            self.banca += PRESTAMO
            self.log(f"Prestamo aceptado: +${PRESTAMO} (deuda total: "
                     f"${self.stats['deuda']}).")
            self.nueva_ronda()
        else:
            self.log("Rechazaste el prestamo. Fin del juego.")
            self.resumen_final()

    # ---------- utilidades ----------
    def actualizar_panel(self):
        self.var_banca.set(f"${self.banca}")
        self.var_apuesta.set(f"${self.apuesta}")
        self.var_racha.set(f"{self.stats['racha']} seguidas")
        self.var_record.set(f"${self.stats['banca_max']}")
        puede_doblar = (self.estado == "jugador"
                        and len(self.mano_jugador) == 2
                        and self.banca >= self.apuesta * 2)
        self.btn_doblar.config(
            state=tk.NORMAL if puede_doblar else tk.DISABLED)

    def log(self, mensaje):
        self.bitacora.insert(tk.END, mensaje)
        self.bitacora.see(tk.END)

    def texto_resumen(self):
        s = self.stats
        neto = self.banca - BANCA_INICIAL
        lineas = [
            "RESUMEN DE TU NOCHE EN EL CASINO",
            "=" * 40,
            f"Rondas jugadas : {s['rondas']}",
            f"Victorias      : {s['victorias']}",
            f"Derrotas       : {s['derrotas']}",
            f"Empates        : {s['empates']}",
            f"Racha maxima   : {s['racha_max']} victorias seguidas",
            f"Banca maxima   : ${s['banca_max']}",
            f"Entraste con   : ${BANCA_INICIAL}",
            f"Sales con      : ${self.banca}",
            f"Balance neto   : {'+' if neto >= 0 else ''}${neto}",
        ]
        if s["prestamos"] > 0:
            lineas.append(f"Prestamos      : {s['prestamos']} "
                          f"(deuda: ${s['deuda']})")
            lineas.append("El prestamista te espera afuera. Corre.")
        if self.banca == 0:
            lineas.append("Te fuiste con los bolsillos vacios. "
                          "La casa siempre gana.")
        return "\n".join(lineas)

    def resumen_final(self):
        messagebox.showinfo("Fin del juego", self.texto_resumen())
        if messagebox.askyesno("¿Revancha?", "¿Quieres jugar de nuevo "
                                             "desde cero?"):
            self.reset_juego()
            self.bitacora.delete(0, tk.END)
            self.nueva_ronda()
        else:
            self.root.destroy()

    def salir(self):
        if messagebox.askyesno("Salir", "¿Seguro que quieres dejar la mesa?"):
            messagebox.showinfo("Resumen", self.texto_resumen())
            self.root.destroy()


def main():
    root = tk.Tk()
    BlackjackApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
