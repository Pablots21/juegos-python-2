# Juegos en Python

Dos juegos hechos en Python con música y efectos de sonido (generados por código).

## 1. Blackjack 21 (`blackjack/`)
Blackjack gráfico con tkinter + pygame (música). Controles: 1 = Pedir, 2 = Plantarse, 3 = Doblar, M = música.

```
cd blackjack
pip install -r requirements.txt
python blackjack.py
```

## 2. Turbo Highway (`turbo-highway/`)
Juego de carros para 1 o 2 jugadores: esquiva el tráfico, junta monedas y usa nitro.
- Jugador 1: W A S D + ESPACIO (nitro)
- Jugador 2: flechas + ENTER (nitro)
- R reinicia, P pausa, M música, ESC menú

```
cd turbo-highway
pip install -r requirements.txt
python carros.py
```

## Música y sonidos
Se generan con `generar_audio.py` (numpy). Los `.wav` ya vienen incluidos.

Autor: Juan Pablo Martínez Acuña
