"""
============================================================
  TURBO HIGHWAY  -  Esquiva el trafico, junta monedas, usa nitro
  1 o 2 jugadores en la misma pista.
  Requiere:  pip install pygame
  (deja los archivos .wav en la misma carpeta que este script)

  JUGADOR 1:  W A S D  mover  |  ESPACIO  nitro
  JUGADOR 2:  FLECHAS  mover  |  ENTER    nitro
  R reiniciar | P pausa | M musica | ESC menu
============================================================
"""

import math
import os
import random
import sys

import pygame

# -------------------- CONFIGURACION --------------------
W, H = 1000, 720
FPS = 60
PANEL_W = 250
ROAD_W = 500
ROAD_X = PANEL_W
LANES = 5
LANE_W = ROAD_W // LANES
CAR_W, CAR_H = 50, 90
VIDAS = 3

VOLUMEN_MUSICA = 0.35
VOLUMEN_EFECTOS = 0.8
EFECTOS = ["choque", "moneda", "nitro", "click", "bip", "go", "fin"]

BG = (14, 16, 26)
ASFALTO = (52, 54, 62)
PASTO = (24, 92, 52)
TEXTO = (236, 240, 245)
DORADO = (250, 204, 21)
COL_P1 = (231, 76, 60)
COL_P2 = (52, 152, 219)
COLORES_TRAFICO = [(241, 196, 15), (46, 204, 113), (155, 89, 182),
                   (230, 126, 34), (149, 165, 166), (26, 188, 156),
                   (236, 240, 241), (192, 57, 43)]


# -------------------- UTILIDADES DE DIBUJO --------------------
def dibujar_carro(surf, x, y, color, llama=False, w=CAR_W, h=CAR_H, franja=False):
    x, y = int(x), int(y)
    oscuro = tuple(max(0, c - 55) for c in color)
    if llama:
        pts = [(x + 10, y + h), (x + w - 10, y + h),
               (x + w // 2, y + h + random.randint(26, 46))]
        pygame.draw.polygon(surf, (255, 140, 0), pts)
        pts2 = [(x + 18, y + h), (x + w - 18, y + h),
                (x + w // 2, y + h + random.randint(12, 22))]
        pygame.draw.polygon(surf, (255, 240, 120), pts2)
    # ruedas
    for wx, wy in ((x - 4, y + 12), (x + w - 5, y + 12),
                   (x - 4, y + h - 34), (x + w - 5, y + h - 34)):
        pygame.draw.rect(surf, (20, 20, 24), (wx, wy, 9, 24), border_radius=3)
    # carroceria
    pygame.draw.rect(surf, color, (x, y, w, h), border_radius=14)
    if franja:
        pygame.draw.rect(surf, (245, 245, 245), (x + w // 2 - 4, y + 2, 8, h - 4))
    # vidrios y techo
    pygame.draw.rect(surf, (170, 215, 240), (x + 8, y + 20, w - 16, 18), border_radius=5)
    pygame.draw.rect(surf, oscuro, (x + 8, y + 38, w - 16, 22), border_radius=4)
    pygame.draw.rect(surf, (130, 175, 205), (x + 9, y + h - 30, w - 18, 12), border_radius=4)
    # luces
    pygame.draw.circle(surf, (255, 250, 190), (x + 10, y + 6), 4)
    pygame.draw.circle(surf, (255, 250, 190), (x + w - 10, y + 6), 4)
    pygame.draw.rect(surf, (230, 30, 30), (x + 5, y + h - 6, 10, 4), border_radius=2)
    pygame.draw.rect(surf, (230, 30, 30), (x + w - 15, y + h - 6, 10, 4), border_radius=2)


def dibujar_corazon(surf, cx, cy, r, color):
    pygame.draw.circle(surf, color, (cx - r // 2, cy - r // 3), r // 2 + 1)
    pygame.draw.circle(surf, color, (cx + r // 2, cy - r // 3), r // 2 + 1)
    pygame.draw.polygon(surf, color, [(cx - r, cy - r // 6), (cx + r, cy - r // 6),
                                      (cx, cy + r)])


def texto(surf, fuente, msg, pos, color=TEXTO, centro=False):
    img = fuente.render(msg, True, color)
    rect = img.get_rect()
    if centro:
        rect.center = pos
    else:
        rect.topleft = pos
    surf.blit(img, rect)
    return rect


class Boton:
    def __init__(self, rect, etiqueta, color, accion):
        self.rect = pygame.Rect(rect)
        self.etiqueta = etiqueta
        self.color = color
        self.accion = accion

    def dibujar(self, surf, fuente, mouse):
        arriba = self.rect.collidepoint(mouse)
        col = tuple(min(255, c + 35) for c in self.color) if arriba else self.color
        pygame.draw.rect(surf, (0, 0, 0), self.rect.move(0, 3), border_radius=10)
        pygame.draw.rect(surf, col, self.rect, border_radius=10)
        texto(surf, fuente, self.etiqueta, self.rect.center, (255, 255, 255), True)


class Jugador:
    def __init__(self, idx, nombre, color, teclas):
        self.idx = idx
        self.nombre = nombre
        self.color = color
        self.teclas = teclas   # izquierda, derecha, arriba, abajo, nitro
        self.reset(0)

    def reset(self, x):
        self.x = float(x)
        self.y = float(H - 190)
        self.vidas = VIDAS
        self.puntos = 0.0
        self.energia = 100.0
        self.inv = 0
        self.vivo = True
        self.nitro = False

    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), CAR_W, CAR_H)

    def mover(self, k):
        izq, der, arr, aba, nit = self.teclas
        self.nitro = False
        if not self.vivo:
            return
        quiere_nitro = any(k[t] for t in nit)
        if quiere_nitro and self.energia > 2:
            self.nitro = True
            self.energia = max(0, self.energia - 0.7)
        else:
            self.energia = min(100, self.energia + 0.18)
        vel = 8.5 if self.nitro else 5.5
        dx = (1 if k[der] else 0) - (1 if k[izq] else 0)
        dy = (1 if k[aba] else 0) - (1 if k[arr] else 0)
        if dx and dy:
            vel *= 0.72
        self.x += dx * vel
        self.y += dy * vel * 0.9
        self.x = max(6, min(ROAD_W - CAR_W - 6, self.x))
        self.y = max(200, min(H - CAR_H - 20, self.y))
        if self.inv > 0:
            self.inv -= 1


# -------------------- JUEGO --------------------
class Juego:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        self.pantalla = pygame.display.set_mode((W, H))
        pygame.display.set_caption("TURBO HIGHWAY - 1 o 2 jugadores")
        self.reloj = pygame.time.Clock()
        self.f_gde = pygame.font.SysFont("arial", 64, bold=True)
        self.f_med = pygame.font.SysFont("arial", 28, bold=True)
        self.f_peq = pygame.font.SysFont("arial", 18, bold=True)
        self.f_mini = pygame.font.SysFont("arial", 15)
        self.mundo = pygame.Surface((ROAD_W, H))

        self.jugadores = [
            Jugador(1, "JUGADOR 1", COL_P1,
                    (pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s,
                     (pygame.K_SPACE,))),
            Jugador(2, "JUGADOR 2", COL_P2,
                    (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN,
                     (pygame.K_RETURN, pygame.K_KP_ENTER))),
        ]
        self.n_jug = 1
        self.estado = "menu"
        self.mejor = {1: 0, 2: 0}
        self.cargar_audio()
        self.crear_botones()
        self.salir_flag = False
        self.offset = 0.0
        self.reset_partida()

    # ---------- audio ----------
    def cargar_audio(self):
        self.sonidos = {}
        self.musica_ok = False
        self.musica_on = False
        try:
            pygame.mixer.init(44100, -16, 2, 512)
        except Exception as e:
            print("No se pudo iniciar el audio:", e)
            return
        carpeta = os.path.dirname(os.path.abspath(__file__))
        for nombre in EFECTOS:
            try:
                s = pygame.mixer.Sound(os.path.join(carpeta, nombre + ".wav"))
                s.set_volume(VOLUMEN_EFECTOS)
                self.sonidos[nombre] = s
            except Exception as e:
                print("Sin efecto", nombre, ":", e)
        try:
            pygame.mixer.music.load(os.path.join(carpeta, "musica.wav"))
            pygame.mixer.music.set_volume(VOLUMEN_MUSICA)
            pygame.mixer.music.play(-1)
            self.musica_ok = True
            self.musica_on = True
        except Exception as e:
            print("No se pudo cargar la musica:", e)

    def sfx(self, nombre):
        s = self.sonidos.get(nombre)
        if s:
            s.play()

    def alternar_musica(self):
        if not self.musica_ok:
            return
        if self.musica_on:
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()
        self.musica_on = not self.musica_on

    # ---------- botones ----------
    def crear_botones(self):
        cx = W // 2
        self.btn_menu = [
            Boton((cx - 150, 300, 300, 58), "1 JUGADOR", (39, 174, 96),
                  lambda: self.iniciar(1)),
            Boton((cx - 150, 372, 300, 58), "2 JUGADORES", (41, 128, 185),
                  lambda: self.iniciar(2)),
            Boton((cx - 150, 444, 300, 58), "MUSICA ON/OFF", (142, 68, 173),
                  self.alternar_musica),
            Boton((cx - 150, 516, 300, 58), "SALIR", (192, 57, 43),
                  self.salir),
        ]
        self.btn_juego = [
            Boton((25, 570, 200, 48), "REINICIAR (R)", (230, 126, 34), self.reiniciar),
            Boton((25, 628, 200, 48), "MENU (ESC)", (127, 140, 141), self.ir_menu),
            Boton((PANEL_W + ROAD_W + 25, 570, 200, 48), "MUSICA (M)", (142, 68, 173),
                  self.alternar_musica),
            Boton((PANEL_W + ROAD_W + 25, 628, 200, 48), "SALIR", (192, 57, 43),
                  self.salir),
        ]

    # ---------- flujo ----------
    def iniciar(self, n):
        self.n_jug = n
        self.reset_partida()

    def reiniciar(self):
        self.reset_partida()

    def ir_menu(self):
        self.estado = "menu"

    def salir(self):
        self.salir_flag = True

    def reset_partida(self):
        self.activos = self.jugadores[:self.n_jug]
        if self.n_jug == 1:
            self.activos[0].reset((ROAD_W - CAR_W) / 2)
        else:
            self.jugadores[0].reset(LANE_W * 1 + (LANE_W - CAR_W) / 2)
            self.jugadores[1].reset(LANE_W * 3 + (LANE_W - CAR_W) / 2)
        self.trafico = []
        self.monedas = []
        self.particulas = []
        self.t = 0
        self.timer_trafico = 30
        self.timer_moneda = 120
        self.shake = 0
        self.scroll = 0.0
        self.velocidad = 7.0
        self.cuenta = 0
        self.fin_timer = 0
        self.estado = "cuenta"
        self.ultimo_num = 4

    # ---------- generacion ----------
    def generar_trafico(self):
        carriles = list(range(LANES))
        random.shuffle(carriles)
        recientes = sum(1 for c in self.trafico if c["y"] < 200)
        if recientes >= 3:
            return
        for ln in carriles:
            x = ln * LANE_W + (LANE_W - CAR_W) // 2
            if all(not (abs(c["x"] - x) < 5 and c["y"] < 180) for c in self.trafico):
                self.trafico.append({"x": x, "y": -CAR_H - 10,
                                     "r": random.uniform(0.25, 0.6),
                                     "color": random.choice(COLORES_TRAFICO)})
                return

    def generar_moneda(self):
        ln = random.randrange(LANES)
        x = ln * LANE_W + LANE_W // 2
        self.monedas.append({"x": x, "y": -30})

    def explosion(self, x, y, color):
        for _ in range(26):
            ang = random.uniform(0, math.tau)
            v = random.uniform(2, 7)
            self.particulas.append({"x": x, "y": y, "vx": math.cos(ang) * v,
                                    "vy": math.sin(ang) * v,
                                    "vida": random.randint(20, 45),
                                    "color": random.choice([color, (255, 160, 0),
                                                            (255, 230, 120)])})

    # ---------- actualizacion ----------
    def actualizar(self, teclas):
        if self.estado == "cuenta":
            self.cuenta += 1
            num = 3 - self.cuenta // 60
            if num != self.ultimo_num:
                self.ultimo_num = num
                self.sfx("go" if num <= 0 else "bip")
            if self.cuenta >= 200:
                self.estado = "juego"
            return
        if self.estado == "over":
            self.shake = max(0, self.shake - 1)
            self.mover_particulas()
            return
        if self.estado != "juego":
            return

        self.t += 1
        seg = self.t / 60
        self.velocidad = 7.0 + min(8.0, seg * 0.12)
        self.scroll = (self.scroll + self.velocidad) % 80

        self.timer_trafico -= 1
        if self.timer_trafico <= 0:
            self.generar_trafico()
            self.timer_trafico = max(14, int(46 - seg * 0.35)) + random.randint(0, 10)
        self.timer_moneda -= 1
        if self.timer_moneda <= 0:
            self.generar_moneda()
            self.timer_moneda = random.randint(150, 320)

        for c in self.trafico:
            c["y"] += self.velocidad * (1 - c["r"])
        self.trafico = [c for c in self.trafico if c["y"] < H + 120]
        for m in self.monedas:
            m["y"] += self.velocidad
        self.monedas = [m for m in self.monedas if m["y"] < H + 40]

        for p in self.activos:
            estaba_nitro = p.nitro
            p.mover(teclas)
            if p.nitro and not estaba_nitro:
                self.sfx("nitro")
            if not p.vivo:
                continue
            p.puntos += self.velocidad * (2.0 if p.nitro else 1.0) / 12
            r = p.rect()
            # monedas
            for m in self.monedas[:]:
                if r.inflate(10, 10).collidepoint(m["x"], m["y"]) or \
                        r.colliderect(pygame.Rect(m["x"] - 14, m["y"] - 14, 28, 28)):
                    self.monedas.remove(m)
                    p.puntos += 100
                    p.energia = min(100, p.energia + 20)
                    self.sfx("moneda")
            # choques
            if p.inv == 0:
                hit = r.inflate(-12, -14)
                for c in self.trafico[:]:
                    if hit.colliderect(pygame.Rect(c["x"], int(c["y"]), CAR_W, CAR_H).inflate(-8, -10)):
                        self.trafico.remove(c)
                        p.vidas -= 1
                        p.inv = 120
                        self.shake = 18
                        self.sfx("choque")
                        self.explosion(r.centerx, r.centery, c["color"])
                        if p.vidas <= 0:
                            p.vivo = False
                            p.nitro = False
                        break

        self.mover_particulas()
        if self.shake > 0:
            self.shake -= 1
        if not any(p.vivo for p in self.activos):
            self.fin_timer += 1
            if self.fin_timer > 50:
                self.terminar()

    def mover_particulas(self):
        for q in self.particulas:
            q["x"] += q["vx"]
            q["y"] += q["vy"]
            q["vida"] -= 1
        self.particulas = [q for q in self.particulas if q["vida"] > 0]

    def terminar(self):
        self.estado = "over"
        self.sfx("fin")
        mejor_p = max(int(p.puntos) for p in self.activos)
        self.mejor[self.n_jug] = max(self.mejor[self.n_jug], mejor_p)

    # ---------- dibujo ----------
    def dibujar_mundo(self):
        m = self.mundo
        m.fill(ASFALTO)
        # bordes tipo "curb"
        off = int(self.scroll)
        for i, yy in enumerate(range(-80, H + 80, 40)):
            col = (230, 230, 230) if i % 2 == 0 else (200, 40, 40)
            pygame.draw.rect(m, col, (0, yy + off, 8, 40))
            pygame.draw.rect(m, col, (ROAD_W - 8, yy + off, 8, 40))
        # lineas de carril
        for i in range(1, LANES):
            x = i * LANE_W
            for yy in range(-80, H + 80, 80):
                pygame.draw.rect(m, (225, 225, 225), (x - 2, yy + off, 4, 40))
        # monedas
        for c in self.monedas:
            pygame.draw.circle(m, (180, 130, 0), (c["x"], int(c["y"])), 15)
            pygame.draw.circle(m, DORADO, (c["x"], int(c["y"])), 12)
            pygame.draw.circle(m, (255, 240, 150), (c["x"] - 3, int(c["y"]) - 3), 4)
        # trafico
        for c in self.trafico:
            dibujar_carro(m, c["x"], c["y"], c["color"])
        # jugadores
        for p in self.activos:
            if not p.vivo:
                continue
            if p.inv > 0 and (p.inv // 5) % 2 == 0:
                continue
            dibujar_carro(m, p.x, p.y, p.color, llama=p.nitro, franja=True)
            texto(m, self.f_peq, f"P{p.idx}", (p.x + CAR_W // 2, p.y - 12),
                  p.color, True)
        # particulas
        for q in self.particulas:
            pygame.draw.circle(m, q["color"], (int(q["x"]), int(q["y"])),
                               max(1, q["vida"] // 10))

    def panel(self, x0, p, mouse):
        pygame.draw.rect(self.pantalla, (22, 25, 38), (x0, 0, PANEL_W, H))
        if p is None:
            texto(self.pantalla, self.f_med, "RECORD", (x0 + PANEL_W // 2, 60), DORADO, True)
            texto(self.pantalla, self.f_gde, str(self.mejor[self.n_jug]),
                  (x0 + PANEL_W // 2, 120), TEXTO, True)
            texto(self.pantalla, self.f_peq, "MODO 1 JUGADOR",
                  (x0 + PANEL_W // 2, 190), (160, 170, 185), True)
            texto(self.pantalla, self.f_mini, "Pulsa 2 jugadores en el menu",
                  (x0 + PANEL_W // 2, 215), (120, 130, 145), True)
            texto(self.pantalla, self.f_mini, "para jugar con un amigo",
                  (x0 + PANEL_W // 2, 235), (120, 130, 145), True)
            return
        pygame.draw.rect(self.pantalla, p.color, (x0, 0, PANEL_W, 8))
        texto(self.pantalla, self.f_med, p.nombre, (x0 + PANEL_W // 2, 40), p.color, True)
        texto(self.pantalla, self.f_peq, "PUNTOS", (x0 + 25, 80), (160, 170, 185))
        texto(self.pantalla, self.f_gde, str(int(p.puntos)), (x0 + 25, 100))
        texto(self.pantalla, self.f_peq, "VIDAS", (x0 + 25, 185), (160, 170, 185))
        for i in range(VIDAS):
            col = (231, 76, 60) if i < p.vidas else (60, 62, 75)
            dibujar_corazon(self.pantalla, x0 + 40 + i * 42, 228, 14, col)
        texto(self.pantalla, self.f_peq, "NITRO", (x0 + 25, 262), (160, 170, 185))
        pygame.draw.rect(self.pantalla, (50, 54, 70), (x0 + 25, 290, 200, 18), border_radius=9)
        ancho = int(200 * p.energia / 100)
        if ancho > 0:
            pygame.draw.rect(self.pantalla, (255, 160, 0) if p.nitro else (52, 211, 153),
                             (x0 + 25, 290, ancho, 18), border_radius=9)
        # controles
        texto(self.pantalla, self.f_peq, "CONTROLES", (x0 + 25, 340), DORADO)
        if p.idx == 1:
            lineas = ["W  acelerar", "S  frenar", "A  izquierda", "D  derecha",
                      "ESPACIO  nitro"]
        else:
            lineas = ["\u2191  acelerar", "\u2193  frenar", "\u2190  izquierda",
                      "\u2192  derecha", "ENTER  nitro"]
        for i, ln in enumerate(lineas):
            texto(self.pantalla, self.f_peq, ln, (x0 + 25, 372 + i * 28))
        if not p.vivo:
            texto(self.pantalla, self.f_med, "ELIMINADO", (x0 + PANEL_W // 2, 540),
                  (231, 76, 60), True)

    def dibujar_juego(self):
        self.pantalla.fill(BG)
        self.dibujar_mundo()
        ox = random.randint(-self.shake, self.shake) if self.shake else 0
        oy = random.randint(-self.shake, self.shake) if self.shake else 0
        self.pantalla.blit(self.mundo, (ROAD_X + ox, oy))
        mouse = pygame.mouse.get_pos()
        self.panel(0, self.jugadores[0], mouse)
        self.panel(ROAD_X + ROAD_W, self.jugadores[1] if self.n_jug == 2 else None, mouse)
        for b in self.btn_juego:
            b.dibujar(self.pantalla, self.f_peq, mouse)
        texto(self.pantalla, self.f_mini, "P = pausa", (PANEL_W + ROAD_W + 25, 690),
              (120, 130, 145))

        cx = ROAD_X + ROAD_W // 2
        if self.estado == "cuenta":
            num = 3 - self.cuenta // 60
            msg = "GO!" if num <= 0 else str(num)
            texto(self.pantalla, self.f_gde, msg, (cx, H // 2 - 60), DORADO, True)
        elif self.estado == "pausa":
            self.velo()
            texto(self.pantalla, self.f_gde, "PAUSA", (cx, H // 2 - 30), TEXTO, True)
            texto(self.pantalla, self.f_peq, "Pulsa P para continuar", (cx, H // 2 + 20),
                  (180, 190, 205), True)
        elif self.estado == "over":
            self.velo()
            if self.n_jug == 1:
                p = self.activos[0]
                texto(self.pantalla, self.f_gde, "GAME OVER", (cx, 250), (231, 76, 60), True)
                texto(self.pantalla, self.f_med, f"Puntos: {int(p.puntos)}", (cx, 330), TEXTO, True)
                texto(self.pantalla, self.f_med, f"Record: {self.mejor[1]}", (cx, 370), DORADO, True)
            else:
                a, b = self.jugadores[0], self.jugadores[1]
                if int(a.puntos) == int(b.puntos):
                    texto(self.pantalla, self.f_gde, "EMPATE", (cx, 250), TEXTO, True)
                else:
                    g = a if a.puntos > b.puntos else b
                    texto(self.pantalla, self.f_gde, f"GANA J{g.idx}!", (cx, 250), g.color, True)
                texto(self.pantalla, self.f_med, f"J1: {int(a.puntos)}", (cx, 330), COL_P1, True)
                texto(self.pantalla, self.f_med, f"J2: {int(b.puntos)}", (cx, 370), COL_P2, True)
            texto(self.pantalla, self.f_peq, "Pulsa R para reiniciar", (cx, 430),
                  (180, 190, 205), True)

    def velo(self):
        s = pygame.Surface((ROAD_W, H), pygame.SRCALPHA)
        s.fill((0, 0, 0, 150))
        self.pantalla.blit(s, (ROAD_X, 0))

    def dibujar_menu(self):
        self.pantalla.fill(BG)
        self.scroll = (self.scroll + 4) % 80
        # carretera decorativa
        pygame.draw.rect(self.pantalla, ASFALTO, (W // 2 - 260, 0, 520, H))
        for yy in range(-80, H + 80, 80):
            pygame.draw.rect(self.pantalla, (225, 225, 225),
                             (W // 2 - 2, yy + int(self.scroll), 4, 40))
        veil = pygame.Surface((520, H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 110))
        self.pantalla.blit(veil, (W // 2 - 260, 0))
        dibujar_carro(self.pantalla, W // 2 - 190, 120, COL_P1, llama=True, franja=True)
        dibujar_carro(self.pantalla, W // 2 + 140, 120, COL_P2, llama=True, franja=True)
        texto(self.pantalla, self.f_gde, "TURBO HIGHWAY", (W // 2, 90), DORADO, True)
        texto(self.pantalla, self.f_peq, "Esquiva el trafico, junta monedas y usa el nitro",
              (W // 2, 160), TEXTO, True)
        mouse = pygame.mouse.get_pos()
        for b in self.btn_menu:
            b.dibujar(self.pantalla, self.f_med, mouse)
        texto(self.pantalla, self.f_mini,
              "J1: W A S D + ESPACIO     |     J2: FLECHAS + ENTER",
              (W // 2, 620), (180, 190, 205), True)
        estado = "ON" if self.musica_on else "OFF"
        texto(self.pantalla, self.f_mini, f"Musica: {estado}", (W // 2, 645),
              (120, 130, 145), True)

    # ---------- eventos / bucle ----------
    def eventos(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.salir_flag = True
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                botones = self.btn_menu if self.estado == "menu" else self.btn_juego
                for b in botones:
                    if b.rect.collidepoint(e.pos):
                        self.sfx("click")
                        b.accion()
                        break
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_m:
                    self.alternar_musica()
                elif self.estado == "menu":
                    if e.key == pygame.K_1:
                        self.iniciar(1)
                    elif e.key == pygame.K_2:
                        self.iniciar(2)
                    elif e.key == pygame.K_ESCAPE:
                        self.salir()
                else:
                    if e.key == pygame.K_r:
                        self.sfx("click")
                        self.reiniciar()
                    elif e.key == pygame.K_ESCAPE:
                        self.ir_menu()
                    elif e.key == pygame.K_p:
                        if self.estado == "juego":
                            self.estado = "pausa"
                        elif self.estado == "pausa":
                            self.estado = "juego"

    def correr(self):
        while not self.salir_flag:
            self.eventos()
            if self.estado == "menu":
                self.dibujar_menu()
            else:
                self.actualizar(pygame.key.get_pressed())
                self.dibujar_juego()
            pygame.display.flip()
            self.reloj.tick(FPS)
        pygame.quit()


if __name__ == "__main__":
    Juego().correr()
    sys.exit()
