import numpy as np, wave, random

SR = 44100
BPM = 128
BEAT = 60 / BPM
BARS = 16
N = int(SR * BEAT * 4 * BARS)
rng = random.Random(11)
nrng = np.random.default_rng(11)


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(n):
    return np.arange(n) / SR


def lp(x, k):
    return np.convolve(x, np.ones(k) / k, mode="same")


def saw(f, n):
    return 2 * ((f * tt(n)) % 1.0) - 1


def fade(sig, a=0.004, r=0.03):
    sig = sig.copy()
    na, nr = int(a * SR), min(int(r * SR), len(sig))
    if na:
        sig[:na] *= np.linspace(0, 1, na)
    if nr:
        sig[-nr:] *= np.linspace(1, 0, nr)
    return sig


buf = np.zeros((2, N))


def add(start, sig, gain, pan=0.0):
    start %= N
    l = gain * np.cos((pan + 1) * np.pi / 4)
    r = gain * np.sin((pan + 1) * np.pi / 4)
    first = min(len(sig), N - start)
    buf[0, start:start + first] += sig[:first] * l
    buf[1, start:start + first] += sig[:first] * r
    rest = len(sig) - first
    if rest > 0:
        buf[0, :rest] += sig[first:] * l
        buf[1, :rest] += sig[first:] * r


def pluck(f, dur, decay=9):
    n = int(dur * SR)
    s = saw(f, n) * 0.6 + saw(f * 1.006, n) * 0.4
    s = lp(s, 3) * np.exp(-tt(n) * decay)
    return fade(s, 0.002, 0.02)


def pad(f, dur):
    n = int(dur * SR)
    s = (saw(f, n) + saw(f * 1.008, n) + saw(f * 0.992, n)) / 3
    s = lp(s, 14)
    env = np.minimum(1, tt(n) / 0.4) * np.minimum(1, (dur - tt(n)) / 0.3)
    return s * np.clip(env, 0, 1)


def bass(f, dur):
    n = int(dur * SR)
    t = tt(n)
    s = lp(saw(f, n), 8) * 0.8 + np.sin(2 * np.pi * f * t) * 0.6
    return fade(s * np.exp(-t * 5), 0.003, 0.02)


def kick():
    n = int(0.25 * SR)
    t = tt(n)
    f = 48 + 110 * np.exp(-t * 35)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 11)


def clap():
    n = int(0.2 * SR)
    x = np.diff(nrng.standard_normal(n + 1))
    return x * np.exp(-tt(n) * 22)


def hat(d=60):
    n = int(0.06 * SR)
    return np.diff(nrng.standard_normal(n + 1)) * np.exp(-tt(n) * d)


# Am - F - C - G
CHORDS = [(45, [57, 60, 64]), (41, [53, 57, 60]),
          (48, [60, 64, 67]), (43, [55, 59, 62])]
PENT = [69, 72, 74, 76, 79, 81]
BASS_PAT = [0, 0, 12, 0, 0, 0, 12, 7]
sixteenth = BEAT / 4
prev = 4

for b in range(BARS):
    root, tones = CHORDS[b % 4]
    t0 = int(b * 4 * BEAT * SR)

    for k, m in enumerate(tones):
        add(t0, pad(hz(m - 12), 4 * BEAT), 0.05, -0.3 + 0.3 * k)

    for i in range(8):
        add(t0 + int(i * BEAT / 2 * SR), bass(hz(root + BASS_PAT[i]), BEAT / 2 * 0.9), 0.5)

    for s in range(16):
        idx = [0, 1, 2, 1][s % 4]
        note = tones[idx] + (12 if (s // 4) % 2 else 0)
        add(t0 + int(s * sixteenth * SR), pluck(hz(note), sixteenth * 1.8, 14),
            0.085, -0.45 if s % 2 else 0.45)

    for beat in range(4):
        add(t0 + int(beat * BEAT * SR), kick(), 0.6)
        add(t0 + int((beat + 0.5) * BEAT * SR), hat(), 0.16, 0.25)
        if beat in (1, 3):
            add(t0 + int(beat * BEAT * SR), clap(), 0.14)
        add(t0 + int((beat + 0.25) * BEAT * SR), hat(110), 0.06, -0.25)

    if (b // 4) in (1, 3):
        for i in range(8):
            if rng.random() < 0.25:
                continue
            prev = max(0, min(len(PENT) - 1, prev + rng.choice([-2, -1, 1, 2])))
            n_ = PENT[prev]
            st = t0 + int(i * BEAT / 2 * SR)
            add(st, pluck(hz(n_), BEAT * 0.8, 5), 0.12, 0.2)
            add(st + int(BEAT * 0.75 * SR), pluck(hz(n_), BEAT * 0.8, 5), 0.05, -0.2)

# reverb circular
ir_n = int(0.7 * SR)
ti = tt(ir_n)
for c in range(2):
    ir = nrng.standard_normal(ir_n) * np.exp(-ti * 6)
    ir /= np.sqrt(np.sum(ir ** 2))
    full = np.zeros(N)
    full[:ir_n] = ir
    wet = np.fft.irfft(np.fft.rfft(buf[c]) * np.fft.rfft(full), n=N)
    buf[c] = buf[c] * 0.85 + wet * 0.25

buf = buf / np.max(np.abs(buf)) * 0.85


def guardar(nombre, data):
    data = np.atleast_2d(data)
    if data.shape[0] == 1:
        data = np.vstack([data, data])
    pcm = (np.clip(data, -1, 1) * 32767).astype(np.int16)
    with wave.open(nombre, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.T.tobytes())


def norm(x, g):
    return x / np.max(np.abs(x)) * g


guardar("musica.wav", buf)

# ---------------- efectos ----------------
# choque
n = int(0.6 * SR)
t = tt(n)
ruido = lp(nrng.standard_normal(n), 6) * np.exp(-t * 7)
golpe = np.sin(2 * np.pi * 70 * t) * np.exp(-t * 9)
guardar("choque.wav", norm(ruido * 0.8 + golpe, 0.9))

# moneda
def blip(f, dur):
    n = int(dur * SR)
    t = tt(n)
    s = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)) * np.exp(-t * 9)
    return fade(s, 0.002, 0.02)

m = np.zeros(int(0.35 * SR))
a, b_ = blip(988, 0.15), blip(1319, 0.25)
m[:len(a)] += a
m[int(0.08 * SR):int(0.08 * SR) + len(b_)] += b_
guardar("moneda.wav", norm(m, 0.6))

# nitro
n = int(0.8 * SR)
t = tt(n)
ruido = np.diff(nrng.standard_normal(n + 1))
ruido = lp(ruido, 3) * np.sin(np.pi * t / 0.8) ** 1.5
tono = np.sin(2 * np.pi * np.cumsum(180 + 900 * (t / 0.8) ** 2) / SR) * 0.3 * np.sin(np.pi * t / 0.8)
guardar("nitro.wav", norm(ruido * 0.8 + tono, 0.6))

# click / cuenta / go
guardar("click.wav", norm(blip(700, 0.08), 0.5))
guardar("bip.wav", norm(blip(440, 0.25), 0.6))
guardar("go.wav", norm(blip(880, 0.6), 0.7))

# fin
fin = np.zeros(int(1.4 * SR))
for i, f in enumerate([392, 330, 262, 196]):
    n = int(0.35 * SR) if i < 3 else int(0.7 * SR)
    t = tt(n)
    ph = 2 * np.pi * f * t
    s = fade((np.sin(ph) + 0.4 * np.sin(2 * ph)) * np.exp(-t * 3), 0.01, 0.1)
    st = int(i * 0.3 * SR)
    fin[st:st + n] += s[:len(fin) - st]
guardar("fin.wav", norm(fin, 0.6))
print("ok", N / SR)
