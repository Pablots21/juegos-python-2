import numpy as np, wave, random

SR = 44100
BPM = 104
BEAT = 60 / BPM
BARS = 16
N = int(SR * BEAT * 4 * BARS)
rng = random.Random(7)
nrng = np.random.default_rng(7)


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def tt(n):
    return np.arange(n) / SR


def fade(sig, a=0.004, r=0.03):
    n = len(sig)
    na, nr = int(a * SR), min(int(r * SR), n)
    sig = sig.copy()
    if na:
        sig[:na] *= np.linspace(0, 1, na)
    if nr:
        sig[-nr:] *= np.linspace(1, 0, nr)
    return sig


def add(buf, start, sig, gain, pan):
    start %= N
    l = gain * np.cos((pan + 1) * np.pi / 4)
    r = gain * np.sin((pan + 1) * np.pi / 4)
    first = min(len(sig), N - start)
    buf[0, start:start + first] += sig[:first] * l
    buf[1, start:start + first] += sig[:first] * r
    rest = len(sig) - first
    if rest > 0:
        buf[0, :rest] += sig[first:] * l
        buf[1, :rest] += sig[first:] * r


# ---------------- instrumentos ----------------
def epiano(f, dur):
    n = int(dur * SR)
    t = tt(n)
    s = (np.sin(2 * np.pi * f * t) * np.exp(-t * 2.5)
         + 0.45 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 5)
         + 0.2 * np.sin(2 * np.pi * 3 * f * t) * np.exp(-t * 8)
         + 0.25 * np.sin(2 * np.pi * 7 * f * t) * np.exp(-t * 25))
    return fade(s, 0.003, 0.05)


def bass(f, dur):
    n = int(dur * SR)
    t = tt(n)
    s = (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(4 * np.pi * f * t)
         + 0.15 * np.sin(6 * np.pi * f * t)) * np.exp(-t * 3.2)
    return fade(s, 0.006, 0.04)


def vibes(f, dur):
    n = int(dur * SR)
    t = tt(n)
    trem = 1 + 0.15 * np.sin(2 * np.pi * 5 * t)
    s = (np.sin(2 * np.pi * f * t) * np.exp(-t * 3.5)
         + 0.3 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 12)) * trem
    return fade(s, 0.002, 0.06)


def hat(gain=1.0):
    n = int(0.07 * SR)
    t = tt(n)
    x = np.diff(nrng.standard_normal(n + 1))
    return x * np.exp(-t * 70) * gain


def brush(gain=1.0):
    n = int(0.22 * SR)
    t = tt(n)
    x = nrng.standard_normal(n)
    x = x - np.convolve(x, np.ones(6) / 6, mode="same") * 0.8
    return x * np.exp(-t * 16) * gain


def kick():
    n = int(0.18 * SR)
    t = tt(n)
    f = 55 + 60 * np.exp(-t * 40)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 18)


# ---------------- armonia ----------------
C_MAJ = [0, 2, 4, 5, 7, 9, 11]
CH = {
    "Dm7":   dict(root=38, third=3, voic=[53, 57, 60, 64], tones=[2, 5, 9, 0], sc=C_MAJ),
    "G7":    dict(root=43, third=4, voic=[55, 59, 62, 65], tones=[7, 11, 2, 5], sc=C_MAJ),
    "Cmaj7": dict(root=36, third=4, voic=[55, 59, 60, 64], tones=[0, 4, 7, 11], sc=C_MAJ),
    "A7":    dict(root=45, third=4, voic=[55, 61, 64, 67], tones=[9, 1, 4, 7], sc=[9, 11, 1, 2, 4, 6, 7]),
    "Fmaj7": dict(root=41, third=4, voic=[52, 57, 60, 64], tones=[5, 9, 0, 4], sc=C_MAJ),
    "Bb7":   dict(root=46, third=4, voic=[56, 62, 65, 68], tones=[10, 2, 5, 8], sc=[10, 0, 2, 3, 5, 7, 8]),
    "Em7":   dict(root=40, third=3, voic=[55, 59, 62, 64], tones=[4, 7, 11, 2], sc=C_MAJ),
}
PROG = ["Dm7", "G7", "Cmaj7", "A7",
        "Dm7", "G7", "Cmaj7", "Cmaj7",
        "Fmaj7", "Bb7", "Em7", "A7",
        "Dm7", "G7", "Cmaj7", "G7"]

buf = np.zeros((2, N))
SW = 2 / 3   # swing

for b, name in enumerate(PROG):
    ch = CH[name]
    nxt = CH[PROG[(b + 1) % BARS]]
    t0 = int(b * 4 * BEAT * SR)

    def at(beat):
        return t0 + int(beat * BEAT * SR)

    # bajo caminante
    approach = nxt["root"] + rng.choice([-1, 1])
    walk = [ch["root"], ch["root"] + ch["third"] + rng.choice([0, 0, 4 - ch["third"]]),
            ch["root"] + rng.choice([7, 7, 12]), approach]
    for i, n_ in enumerate(walk):
        add(buf, at(i), bass(hz(n_), BEAT * 0.95), 0.55, 0.0)

    # piano (comping tipo Charleston, variado)
    hits = [(0, 1.6), (1 + SW, 1.0)]
    if rng.random() < 0.5:
        hits.append((2.5 + 0.5, 0.9))
    if rng.random() < 0.35:
        hits = [(0, 1.0), (2 + SW, 1.2)]
    for pos, d in hits:
        for k, m in enumerate(ch["voic"]):
            add(buf, at(pos) + k * 300, epiano(hz(m), d * BEAT), 0.13, -0.35)

    # bateria con escobillas
    for beat_pos, g in [(0, 0.5), (1, 0.55), (1 + SW, 0.3), (2, 0.5),
                        (3, 0.55), (3 + SW, 0.3)]:
        add(buf, at(beat_pos), hat(0.22 * g * 2), 1.0, 0.3)
    for beat_pos in (1, 3):
        add(buf, at(beat_pos), brush(0.12), 1.0, 0.1)
    add(buf, at(0), kick(), 0.18, 0.0)
    if rng.random() < 0.4:
        add(buf, at(2 + SW), kick(), 0.1, 0.0)

# melodia (vibrafono), toma el acorde de cada compas
prev = 72
for b, name in enumerate(PROG):
    ch = CH[name]
    t0 = int(b * 4 * BEAT * SR)
    scale_notes = [m for m in range(64, 85) if m % 12 in ch["sc"]]
    tone_notes = [m for m in range(64, 85) if m % 12 in ch["tones"]]
    resting = (b % 4 == 3 and rng.random() < 0.5) or b == 15
    for beat in range(4):
        for half in (0, 1):
            pos = beat + (SW if half else 0)
            if resting and beat >= 2:
                continue
            if rng.random() < (0.38 if half else 0.25):
                continue
            if half == 0:
                cand = sorted(tone_notes, key=lambda m: abs(m - prev) + rng.random() * 3)
                note = cand[0]
            else:
                step = rng.choice([-2, -1, 1, 2])
                idx = min(range(len(scale_notes)), key=lambda i: abs(scale_notes[i] - prev))
                idx = max(0, min(len(scale_notes) - 1, idx + step))
                note = scale_notes[idx]
            prev = note
            dur = BEAT * (0.9 if half else 1.3)
            add(buf, t0 + int(pos * BEAT * SR), vibes(hz(note), dur), 0.17, 0.4)

# reverb circular (loop perfecto)
ir_n = int(0.9 * SR)
ti = tt(ir_n)
for ch_i in range(2):
    ir = nrng.standard_normal(ir_n) * np.exp(-ti * 4.5)
    ir /= np.sqrt(np.sum(ir ** 2))
    ir_full = np.zeros(N)
    ir_full[:ir_n] = ir
    wet = np.fft.irfft(np.fft.rfft(buf[ch_i]) * np.fft.rfft(ir_full), n=N)
    buf[ch_i] = buf[ch_i] * 0.8 + wet * 0.35

peak = np.max(np.abs(buf))
buf = buf / peak * 0.85


def guardar(nombre, data):
    data = np.atleast_2d(data)
    if data.shape[0] == 1:
        data = np.vstack([data, data])
    pcm = (np.clip(data, -1, 1) * 32767).astype(np.int16)
    with wave.open(nombre, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.T.tobytes())


guardar("musica.wav", buf)


# ---------------- efectos ----------------
def campana(f, dur, g=1.0):
    n = int(dur * SR)
    t = tt(n)
    s = (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 8)
         + 0.2 * np.sin(2 * np.pi * 5.4 * f * t) * np.exp(-t * 14)) * np.exp(-t * 5)
    return fade(s, 0.002, 0.05) * g


def secuencia(notas, paso, dur, total):
    out = np.zeros(int(total * SR))
    for i, f in enumerate(notas):
        s = campana(f, dur, 0.5)
        st = int(i * paso * SR)
        out[st:st + len(s)] += s[:len(out) - st]
    return out


# carta repartida
n = int(0.11 * SR)
t = tt(n)
ruido = np.diff(nrng.standard_normal(n + 1)) * np.exp(-t * 45)
thud = np.sin(2 * np.pi * 170 * t) * np.exp(-t * 50) * 0.6
carta = ruido * 0.9 + thud
guardar("carta.wav", carta / np.max(np.abs(carta)) * 0.7)

# ganar
c5, e5, g5, c6, e6 = 523.25, 659.25, 783.99, 1046.5, 1318.5
ganar = secuencia([c5, e5, g5, c6], 0.11, 0.9, 1.4)
guardar("ganar.wav", ganar / np.max(np.abs(ganar)) * 0.75)

# blackjack natural (fanfarria)
bj = secuencia([c5, e5, g5, c6, g5, c6, e6, g5 * 2], 0.09, 1.0, 1.8)
acorde = sum(campana(f, 1.4, 0.4) for f in (c5, e5, g5, c6))
bj[int(0.75 * SR):int(0.75 * SR) + len(acorde)] += acorde[:len(bj) - int(0.75 * SR)]
guardar("blackjack.wav", bj / np.max(np.abs(bj)) * 0.8)

# perder (trombon triste)
def triste(f0, f1, dur):
    n = int(dur * SR)
    t = tt(n)
    f = np.linspace(f0, f1, n)
    ph = 2 * np.pi * np.cumsum(f + 3 * np.sin(2 * np.pi * 6 * t)) / SR
    s = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)
    return fade(s, 0.02, 0.08) * 0.4

perder = np.zeros(int(1.5 * SR))
for i, (a, b2, d) in enumerate([(311, 293, 0.3), (293, 277, 0.3), (277, 261, 0.3), (261, 196, 0.6)]):
    s = triste(a, b2, d)
    st = int(sum([0.3, 0.3, 0.3][:i]) * SR)
    perder[st:st + len(s)] += s[:len(perder) - st]
guardar("perder.wav", perder / np.max(np.abs(perder)) * 0.7)

# empate
emp = secuencia([e5, e5], 0.18, 0.6, 0.9)
guardar("empate.wav", emp / np.max(np.abs(emp)) * 0.6)
print("ok", N / SR, "segundos")
